﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Swen1;

namespace UnitTests
{
    [TestClass]
    public class UnitTest17
    {
        [TestMethod]
        public void UnitTest17DeleteAccount()
        {
            string username = "unit";
            string password = "test2";
            int expected = 1;

            DataHandler.Instance.DeleteAccount(username,password);
            int actual = DataHandler.Instance.UserNameCheck(username);

            Assert.AreEqual(expected, actual);


        }
    }
}