﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Swen1;

namespace UnitTests
{
    [TestClass]
    public class UnitTest13
    {
        [TestMethod]
        public void UnitTest13CreateCard()
        {
            Card card = new Card();
            card.id = "test";
            card.Name = "Otto";
            card.Damage = 10;
            card.Element = "Water";
            card.Type = "Monster";

            DataHandler.Instance.CreateCard(card);

            int expected = 0;
            int actual = DataHandler.Instance.CardCheck(card.id);

            Assert.AreEqual(expected, actual);


        }
    }
}