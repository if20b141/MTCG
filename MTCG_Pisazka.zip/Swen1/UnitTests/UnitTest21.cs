﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Swen1;

namespace UnitTests
{
    [TestClass]
    public class UnitTest21
    {
        [TestMethod]
        public void UnitTest1KnightVSWaterSpell()
        {
            FightNight fight = new FightNight();
            FightCard card1 = new FightCard();
            FightCard card2 = new FightCard();

            card1.Name = "Spell";
            card1.ElementType = "Water";
            card1.Damage = 10;
            card1.CardType = "Spell";

            card2.Name = "Knight";
            card2.ElementType = "Fire";
            card2.Damage = 15;
            card2.CardType = "Monster";

            string expected = "1";


            List<string> actual = new List<string>();
            actual = fight.Attack(card1, card2);
            Assert.AreEqual(expected, actual[0], "Bei dem Kampf stimmt was nicht");


        }
    }
}