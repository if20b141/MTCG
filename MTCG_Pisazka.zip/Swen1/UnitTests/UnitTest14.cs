﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Swen1;

namespace UnitTests
{
    [TestClass]
    public class UnitTest14
    {
        [TestMethod]
        public void UnitTest14CardToStack()
        {
            string cardid = "test";
            string username = "unit";

            DataHandler.Instance.BuyCard(username, cardid);

            int expected = 1;
            int actual = DataHandler.Instance.CheckIfCardOwned(DataHandler.Instance.GetUserid(username), cardid);

            Assert.AreEqual(expected, actual);


        }
    }
}