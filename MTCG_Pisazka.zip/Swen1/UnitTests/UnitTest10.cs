﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Swen1;

namespace UnitTests
{
    [TestClass]
    public class UnitTest10
    {
        [TestMethod]
        public void UnitTest10Register()
        {
            string username = "unit";
            string password = "test";
            int expected = 0;

            DataHandler.Instance.RegisterUser(username, password);
            int actual = DataHandler.Instance.UserNameCheck(username);

            Assert.AreEqual(expected, actual);
        }
    }
}