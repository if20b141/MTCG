﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Swen1;

namespace UnitTests
{
    [TestClass]
    public class UnitTest5
    {
        [TestMethod]
        public void UnitTest5FireSpellVSWaterSpell()
        {
            FightNight fight = new FightNight();
            FightCard card1 = new FightCard();
            FightCard card2 = new FightCard();

            card1.Name = "Spell";
            card1.ElementType = "Fire";
            card1.Damage = 90;
            card1.CardType = "Spell";

            card2.Name = "Spell";
            card2.ElementType = "Water";
            card2.Damage = 05;
            card2.CardType = "Spell";

            string expected = "1";

            List<string> actual = new List<string>();
            actual = fight.Attack(card1, card2);
            Assert.AreEqual(expected, actual[0], "Bei dem Kampf stimmt was nicht");
        }
    }
}