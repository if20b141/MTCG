﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Swen1;

namespace UnitTests
{
    [TestClass]
    public class UnitTest11
    {
        [TestMethod]
        public void UnitTest11Login()
        {
            string username = "unit";
            string password = "test";
            int expected = 1;

            int actual = DataHandler.Instance.Login(username, password);

            Assert.AreEqual(expected, actual);

            
        }
    }
}