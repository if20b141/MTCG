﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Swen1;

namespace UnitTests
{
    [TestClass]
    public class UnitTest16
    {
        [TestMethod]
        public void UnitTest16DeleteCard()
        {
            string cardid = "test";

            DataHandler.Instance.DeleteCard(cardid);

            int expected = 0;
            int actual = DataHandler.Instance.CardCheck(cardid);

            Assert.AreEqual(expected, actual);


        }
    }
}