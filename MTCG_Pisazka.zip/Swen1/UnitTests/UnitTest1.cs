using Microsoft.VisualStudio.TestTools.UnitTesting;
using Swen1;

namespace UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void UnitTest1WaterGoblinVSFireTroll()
        {
            FightNight fight = new FightNight();
            FightCard card1 = new FightCard();
            FightCard card2 = new FightCard();

            card1.Name = "Goblin";
            card1.ElementType = "Water";
            card1.Damage = 10;
            card1.CardType = "Monster";

            card2.Name = "Troll";
            card2.ElementType = "Fire";
            card2.Damage = 15;
            card2.CardType = "Monster";

            List<string> expected = new List<string>();
            string expectedtext = "PlayerA: " + card1.ElementType + card1.Name + "(" + card1.Damage.ToString() + " Damage) vs PlayerB: " + card2.ElementType + card2.Name + "(" + card2.Damage.ToString() + " Damage) => ";
            expectedtext += card2.Name + " defeats " + card1.Name;
            expected.Add("0");
            expected.Add(expectedtext);

            List<string> actual = new List<string>();
            actual = fight.Attack(card1, card2);
            Assert.AreEqual(expected[0], actual[0], "Bei dem Kampf stimmt was nicht");
            

        }
    }
}