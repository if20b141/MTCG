﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Swen1;

namespace UnitTests
{
    [TestClass]
    public class UnitTest15
    {
        [TestMethod]
        public void UnitTest15DeleteCardFromStack()
        {
            string cardid = "test";
            string username = "unit";

            DataHandler.Instance.ChangeCardamount(DataHandler.Instance.GetUserid(username),cardid,-1);

            int expected = 0;
            int actual = DataHandler.Instance.CheckIfCardOwned(DataHandler.Instance.GetUserid(username), cardid);

            Assert.AreEqual(expected, actual);


        }
    }
}