﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Swen1;

namespace UnitTests
{
    [TestClass]
    public class UnitTest12
    {
        [TestMethod]
        public void UnitTest12ChangePassword()
        {
            string username = "unit";
            string password = "test";
            string newpassword = "test2";
            int expected = 1;

            DataHandler.Instance.UniqueFeature(username, password, newpassword);
            int actual = DataHandler.Instance.Login(username, newpassword);

            Assert.AreEqual(expected, actual);


        }
    }
}