﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class PrepareFighter
    {
        public FightUser PrepareUser(int userid)
        {
            FightUser user = new FightUser();
            Deck deck = new Deck();

            user.Username = DataHandler.Instance.GetUsername(userid);
            List<string> cardids = new List<string>();
            cardids = DataHandler.Instance.GetCardsFromDeck(userid);

            foreach (string cardid in cardids)
            {
                FightCard card = new FightCard();
                List<string> cardinfos = new List<string>();
                cardinfos = DataHandler.Instance.GetCardInfo(cardid);
                card.Name = cardinfos[0];
                card.Damage = int.Parse(cardinfos[1]);
                card.ElementType = cardinfos[2];
                card.CardType = cardinfos[3];
                deck.AddCard(card);
            }
            user.UserDeck = deck;
            return user;

        }
    }
}
