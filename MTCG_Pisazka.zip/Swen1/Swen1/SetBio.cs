﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class SetBio
    {
        public string SetMybio(string username, string body)
        {
            Response response = new Response();
            DeserializeBio deserializeBio = new DeserializeBio();
            TheBio theBio = deserializeBio.dezerialzebio(body);

            int answer = DataHandler.Instance.SetBio(DataHandler.Instance.GetUserid(username), theBio.Name, theBio.Bio, theBio.Image);
            if(answer == 0)
            {
                return response.BuildResponse("200 OK ", "", "DIe Bio des Users wurde erfolgreich Geupdatet");   
            }
            else if(answer == 1)
            {
                return response.BuildResponse("201 OK ", "", "Die Bio des Users wurde Erfolgreich erstellt");
            }
            else
            {
                return response.BuildResponse("401 ERROR", "", "ERROR");
            }
        }
    }
}
