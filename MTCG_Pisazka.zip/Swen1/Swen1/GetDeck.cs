﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class GetDeck
    {
        public string GetYourDeck(string username)
        {
            Response response = new Response();

            List<string> cardids = new List<string>();
            cardids = DataHandler.Instance.GetCardsFromDeck(DataHandler.Instance.GetUserid(username));

            if (cardids.Count > 0)
            {

                List<string> cardinfo = new List<string>();
                string toreturn = "";

                foreach (string cardid in cardids)
                {
                    cardinfo = DataHandler.Instance.GetCardInfo(cardid);
                    Console.WriteLine(cardinfo[0] + " " + cardinfo[1] + " " + cardinfo[2] + " " + cardinfo[3]);
                    toreturn += "{\"Name\": \"" + cardinfo[0] + "\", \"Damage\": \"" + cardinfo[1] + "\", \"Element\": \"" + cardinfo[2] + "\", \"Type\": \"" + cardinfo[3] + "\"}, ";
                }
                return response.BuildResponse("200 OK ", "--header Content-Type: application/json", "[" + toreturn + "]");
            }
            else
            {
                return response.BuildResponse("203 OK ", "", "Das Deck ist noch leer");
            }
        }
    }
}
