﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class GetScoreBoard
    {
        public string GetScore(string username)
        {
            Response response = new Response();

            List<int> userids = new List<int>();
            userids = DataHandler.Instance.GetTopUsers();
            string responsebody = "";

            foreach(int userid in userids)
            {
                List<string> scores = new List<string>();
                scores = DataHandler.Instance.GetUserScoreInfo(userid);
                responsebody += "{\"username\": \"" + scores[0] + "\", \"ELO\": \"" + scores[1] +"\"}, ";
            }
            return response.BuildResponse("200 OK ", "--header Conent-Type: application/json", "[" + responsebody + "]");
        }
    }
}
