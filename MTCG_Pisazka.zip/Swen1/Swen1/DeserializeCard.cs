﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Swen1
{
    public class DeserializeCard
    {
        public List<InputCard> Deserialize(string json)
        {
            List<InputCard> cards = new List<InputCard>();
            cards = JsonConvert.DeserializeObject<List<InputCard>>(json);
            return cards;
        }
    }
}
