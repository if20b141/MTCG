﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class FightCard
    {
        public string Name { get; set; }
        public int Damage { get; set; }
        public string ElementType { get; set; }
        public string CardType { get; set; }

        public List<string> Specialities(FightCard EnemyCard)
        {
            string text;
            List<string> list = new List<string>();
            if (this.Name == "Goblin" && EnemyCard.Name == "Dragon")
            {
                Console.WriteLine("Goblins are too afraid of Dragons to attack. ");
                text = "Goblins are too afraid of Dragons to attack. ";
                list.Add("1");
                list.Add(text);
                return list;
            }
            else if (this.Name == "Ork" && EnemyCard.Name == "Wizard")
            {
                Console.WriteLine("Wizard can control Orks so they are not able to damage them.");
                text = "Wizard can control Orks so they are not able to damage them.";
                list.Add("1");
                list.Add(text);
                return list;
            }
            else if (this.Name == "Dragon" && EnemyCard.Name == "Elve" && EnemyCard.ElementType == "Fire")
            {
                Console.WriteLine("The FireElves know Dragons since they were little and can evade their attacks. ");
                text = "The FireElves know Dragons since they were little and can evade their attacks. ";
                list.Add("1");
                list.Add(text);
                return list;
            }
            else if (this.Name == "Knight" && EnemyCard.CardType == "Spell" && EnemyCard.ElementType == "Water")
            {
                Console.WriteLine("The armor of Knights is so heavy that WaterSpells make them drown them instantly.");
                text = "The armor of Knights is so heavy that WaterSpells make them drown them instantly.";
                list.Add("1");
                list.Add(text);
                return list;
            }
            else if (this.CardType == "Spell" && EnemyCard.Name == "Kraken")
            {
                Console.WriteLine("The Kraken is immune against spells.");
                text = "The Kraken is immune against spells.";
                list.Add("1");
                list.Add(text);
                return list;
            }
            else
            {
                list.Add("0");
                return list;
            }
        }
        public int EffectivenessCheck(FightCard EnemyCard)
        {
            if (this.CardType == "Monster" && EnemyCard.CardType == "Monster")
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        public int Effectiveness(FightCard EnemyCard)
        {
            if (this.ElementType == "Water" && EnemyCard.ElementType == "Fire")
            {
                return 1;
            }
            else if (this.ElementType == "Fire" && EnemyCard.ElementType == "Normal")
            {
                return 1;
            }
            else if (this.ElementType == "Normal" && EnemyCard.ElementType == "Water")
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
}
