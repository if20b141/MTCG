﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class GetTrades
    {
        public string GetAllTrades(string username)
        {
            Response response = new Response();

            List<string> tradeids = new List<string>();
            List<string> tradeinfos = new List<string>();
            string returnbody = "";

            tradeids = DataHandler.Instance.GetAllTradeWithoutMine(DataHandler.Instance.GetUserid(username));
            Console.WriteLine(tradeids.Count);
            if (tradeids.Count > 0)
            {
                foreach (string tradeid in tradeids)
                {
                        tradeinfos = DataHandler.Instance.GetTradeInfos(tradeid);
                        returnbody += "{\"Id\": \"" + tradeinfos[0] + "\", \"CardToTrade\": \"" + tradeinfos[2] + "\", \"Type\": \"" + tradeinfos[3] + "\", \"MinimumDamage\":" + tradeinfos[4] + "}, ";
                }
                    return response.BuildResponse("200 OK ", "--header Conent-Type: application/json", "[" + returnbody + "]");
            }
            else if(tradeids.Count == 0)
            {
                return response.BuildResponse("203 OK ", "", "Es werden zurzeit keine Karten zum Handeln angeboten");
            }
            else
            {
                return response.BuildResponse("401 ERROR ", "", "ERROR");
            }

        }
    }
}
