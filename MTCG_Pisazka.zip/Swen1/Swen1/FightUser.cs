﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class FightUser
    {
        public string Username { get; set; }
        public Deck UserDeck { get; set; }

    }
}
