﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class SetDeck
    {
        public string SetMyDeck(string username, string body)
        {
            Response response = new Response();
            DeserializeCardIDs deserializeCardIDs = new DeserializeCardIDs();

            List<string> list = new List<string>();
            list = deserializeCardIDs.Deserialize(body);
            int allcardsowned = 1;

            foreach(string cardID in list)
            {
                int check = DataHandler.Instance.CheckIfCardOwned(DataHandler.Instance.GetUserid(username), cardID);
                if(check == 0)
                {
                    allcardsowned = 0;
                }
            }
            if(list.Count == 4 && allcardsowned == 1)
            {
                DataHandler.Instance.AddCardToDeck(DataHandler.Instance.GetUserid(username), list);
                foreach(string cardID in list)
                {
                    DataHandler.Instance.ChangeCardamount(DataHandler.Instance.GetUserid(username), cardID, -1);
                }
                return response.BuildResponse("200 OK ", "", "Das Deck wurde erfolgreich erstellt");
            }
            else if(list.Count < 4 || list.Count > 4)
            {
                return response.BuildResponse("400 ERROR ", "", "Der User hat entweder Zuviel oder Zuwenig Karten angegeben");
            }
            else if(allcardsowned != 1)
            {
                return response.BuildResponse("403 ERROR ", "", "Der User besitzt nicht alle angegebenen Karten");
            }
            else
            {
                return response.BuildResponse("404 ERROR", "", "ERROR");
            }
        }
    }
}
