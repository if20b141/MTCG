﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Swen1
{
    public class GetCommand
    {
        public List<string> Commands(string data)
        {
            List<string> commands = new List<string>();
            string[] strings = data.Split(" ");
            
            string body = "";
            int counter = 0;
            string token = "";
            foreach(string s in strings)
            {
                if(counter == 0)
                {
                    //method
                    commands.Add(s);
                }
                else if(counter == 1)
                {
                    //url
                    commands.Add(s);
                }
                if (s.Contains("mtcgToken") && s != "")
                {
                    //token
                    commands.Add(s);
                    token = s;
                }
                if((s.Contains("[") || s.Contains("]") || s.Contains("{") || s.Contains("}") || s.Contains(",") || s.Contains("\"")) && s != "")
                {
                    body += s;
                    body += " ";
                }

                counter++;
            }   
            //body added to list
            commands.Add(body);
            string[] thebody = body.Split("\n");
            List<string> result = new List<string>();
            result.Add(commands[0]);
            result.Add(commands[1]);
            if (token != "")
            {
                string[] tokenparts = token.Split("-");
                result.Add(tokenparts[0]);
            }
            result.Add(thebody.Last());

            return result;

        }


    }
}
