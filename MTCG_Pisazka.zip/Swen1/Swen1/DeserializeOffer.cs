﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Swen1
{
    public class DeserializeOffer
    {
        public string dezerialzeoffer(string json)
        {
            string card;
            card = JsonConvert.DeserializeObject<string>(json);
            Console.WriteLine(card);
            return card;
        }
    }
}
