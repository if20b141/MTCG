﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class DezerializeUnique
    {
        public List<string> Deserialize(string json)
        {
            List<string> values = new List<string>();
            values = JsonConvert.DeserializeObject<List<string>>(json);
            return values;

        }
    }
}
