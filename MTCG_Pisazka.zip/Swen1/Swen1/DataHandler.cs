﻿using Microsoft.EntityFrameworkCore.Diagnostics;
using Newtonsoft.Json.Converters;
using Npgsql;
using Npgsql.EntityFrameworkCore.PostgreSQL.Query.ExpressionTranslators.Internal;
using Npgsql.PostgresTypes;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Swen1
{
    public class DataHandler
    {
        public static readonly DataHandler Instance = new DataHandler();

        private string connectionString;
        private DataHandler()
        {
            GetConnectionString(10);
        }
        public void GetConnectionString(int maxSemaphore)
        {
            connectionString = String.Format(
                "Server={0}; Username={1}; Database={2}; Port={3}; Password={4}; SSLMode=Prefer",
                host,
                user,
                dbName,
                port,
                password);
            semaphore = new SemaphoreSlim(maxSemaphore);
        }

        public SemaphoreSlim semaphore;
        string host = "localhost";
        string user = "postgres";
        string dbName = "SWEN";
        string port = "5432";
        string password = "2208";

        public int UserNameCheck(string NewUsername)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();


            using (var Command = new NpgsqlCommand("SELECT id FROM usertable WHERE username = @newusername", newConnection))
            {
                Command.Parameters.AddWithValue("newusername", NewUsername);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                if (dr.Read() == true)
                {
                    newConnection.Close();
                    semaphore.Release();
                    return 0;
                    //user exists already
                }
                else if (dr.Read() == false)
                {
                    newConnection.Close();
                    semaphore.Release();
                    return 1;
                    //user does not exist
                }
                else
                {
                    Console.WriteLine("nix gut");
                    newConnection.Close();
                    semaphore.Release();
                    return -1;
                }
            }


        }
        public void RegisterUser(string NewUsername, string NewPassword)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();

            using (var Command = new NpgsqlCommand("Insert into usertable(username, userpassword, usercoins, usereloid, accounttype) Values(@username, @userpassword, @coins, @elo, @type)", newConnection))
            {

                Command.Parameters.AddWithValue("username", NewUsername);
                Command.Parameters.AddWithValue("userpassword", NewPassword);
                Command.Parameters.AddWithValue("coins", 20);
                Command.Parameters.AddWithValue("elo", 100);
                Command.Parameters.AddWithValue("type", 0);

                Command.Prepare();
                Command.ExecuteNonQuery();
                newConnection.Close();
                semaphore.Release();
                

            }
        }
        public void DeleteAccount(string username, string password)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();

            using (var Command = new NpgsqlCommand("DELETE FROM usertable WHERE username = @username AND userpassword = @userpassword", newConnection))
            {
                Command.Parameters.AddWithValue("username", username);
                Command.Parameters.AddWithValue("userpassword", password);

                Command.Prepare();
                Command.ExecuteNonQuery();
                newConnection.Close();
                semaphore.Release();
            }
        }
        public int Login(string UserName, string Password)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();

            using (var Command = new NpgsqlCommand("SELECT * FROM usertable WHERE username = @username AND userpassword = @password", newConnection))
            {
                Command.Parameters.AddWithValue("username", UserName);
                Command.Parameters.AddWithValue("password", Password);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                if (dr.Read())
                {
                    string GetUsername = dr.GetString(1);
                    string GetPassword = dr.GetString(2);
                    Console.WriteLine("username : " + GetUsername + " password: " + GetPassword);
                    newConnection.Close();
                    semaphore.Release();
                    return 1;

                }
                else
                {
                    newConnection.Close();
                    semaphore.Release();
                    Console.WriteLine("nix gut");
                    return -1;
                }
            }
        }
        public void SaveToken(string token, long time)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("INSERT into tokens(tokentype, tokenname, timestamp) VALUES(@tokentype, @tokenname, @timestamp)", newConnection))
            {
                Command.Parameters.AddWithValue("tokentype", "Basic");
                Command.Parameters.AddWithValue("tokenname", token);
                Command.Parameters.AddWithValue("timestamp", time);

                Command.Prepare();
                Command.ExecuteNonQuery();
                newConnection.Close();
                semaphore.Release();
            }
        }
        public void TokenUpdate(string token, long time)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("UPDATE tokens SET timestamp = @time WHERE tokenname = @token", newConnection))
            {
                Command.Parameters.AddWithValue("time", time);
                Command.Parameters.AddWithValue("token", token);

                Command.Prepare();
                Command.ExecuteNonQuery();
                newConnection.Close();
                semaphore.Release();
            }
        }
        public int TokenCheck(string token)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("SELECT * FROM tokens WHERE tokenname = @token", newConnection))
            {
                Command.Parameters.AddWithValue("token", token);
                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                if (dr.Read() == true)
                {

                        newConnection.Close();
                        semaphore.Release();
                        return 0;
                        Console.WriteLine("passt");
                        //token exists already and ist still logged in

                }
                else if (dr.Read() == false)
                {
                    newConnection.Close();
                    semaphore.Release();
                    return 1;
                    //token does not exist
                }
                else
                {
                    newConnection.Close();
                    semaphore.Release();
                    return -1;
                    //error
                }
            }
        }
        public void CreateCard(Card card)
        {
            int check = CardCheck(card.id);
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            if (check == 1)
            {
                using (var Command = new NpgsqlCommand("INSERT into card(id, cardname, carddamage, cardelementtype, cardtype) VALUES (@id, @cardname, @carddamage, @cardelement, @cardtype)", newConnection))
                {
                    Command.Parameters.AddWithValue("id", card.id);
                    Command.Parameters.AddWithValue("cardname", card.Name);
                    Command.Parameters.AddWithValue("carddamage", card.Damage);
                    Command.Parameters.AddWithValue("cardelement", card.Element);
                    Command.Parameters.AddWithValue("cardtype", card.Type);

                    Command.Prepare();
                    Command.ExecuteNonQuery();
                    newConnection.Close();
                    semaphore.Release();

                }
            }
        }
        public void DeleteCard(string cardid)
        {
            int check = CardCheck(cardid);
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            if(check == 1)
            {
                using(var Command = new NpgsqlCommand("DELETE FROM card WHERE id = @id", newConnection))
                {
                    Command.Parameters.AddWithValue("id", cardid);

                    Command.Prepare();
                    Command.ExecuteNonQuery();
                    newConnection.Close();
                    semaphore.Release();
                }
            }
        }
        public int CardCheck(string cardid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT id FROM card WHERE id = @id", newConnection))
            {
                Command.Parameters.AddWithValue("id", cardid);
                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                if(dr.Read())
                {
                    newConnection.Close();
                    semaphore.Release();
                    return 0;
                    //card existiert bereits
                }
                else
                {
                    newConnection.Close();
                    semaphore.Release();
                    return 1;
                    //card existiert noch nicht
                }
            }
        }
        public int CreatePackageId(long timestamp)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("INSERT into allpackages (timestamp) VALUES (@timestamp) RETURNING id", newConnection))
            {
                Command.Parameters.AddWithValue("timestamp", timestamp);
                Command.Prepare();
                Object response = Command.ExecuteScalar();
                newConnection.Close();
                semaphore.Release();
                return (int)response;

                
            }
        }
        public void CreatePackage(int packageid, string cardid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("INSERT into packages(packageid, cardid) VALUES (@packageid, @cardid)", newConnection))
            {
                Command.Parameters.AddWithValue("packageid", packageid);
                Command.Parameters.AddWithValue("cardid", cardid);

                Command.Prepare();
                Command.ExecuteNonQuery();
                newConnection.Close();
                semaphore.Release();
            }
        }
        public int GetPackages()
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("SELECT id FROM allpackages ORDER BY id ASC", newConnection))
            {
                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                if (dr.Read())
                {
                    int packageid = dr.GetInt32(0);
                    newConnection.Close();
                    semaphore.Release();
                    return packageid;
                }
                else
                {
                    semaphore.Release();
                    newConnection.Close();
                    return -1;
                }

            }
        }
        public void DeletePackage(int packageid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("DELETE FROM allpackages WHERE id = @id", newConnection))
            {
                Command.Parameters.AddWithValue("id", packageid);

                Command.Prepare();
                Command.ExecuteNonQuery();
                newConnection.Close();
                semaphore.Release();
            }
        }
        public int GetPackId(int allpacks)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT id FROM allpackages", newConnection))
            {
                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                if (dr.Read())
                {
                    int returnthis = dr.GetInt32(allpacks);
                    newConnection.Close();
                    semaphore.Release();
                    return returnthis;
                    //return das zu kaufende pack
                }
                else
                {
                    newConnection.Close();
                    semaphore.Release();
                    return -1;
                    //nix gut
                }
            }
        }
        public List<string> GetCardsFromPack(int packid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT cardid FROM packages WHERE packageid = @packid", newConnection))
            {
                Command.Parameters.AddWithValue("packid", packid);
                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                List<string> cards = new List<string>();
                while (dr.Read())
                {
                        cards.Add(dr.GetString(0));
                }
                newConnection.Close();
                semaphore.Release();
                return cards;
            }
        }
        public int GetUserid(string username)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();

            using (var Command = new NpgsqlCommand("SELECT id FROM usertable WHERE username = @username", newConnection))
            {
                Command.Parameters.AddWithValue("username", username);
                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                if (dr.Read())
                {
                    int userid = dr.GetInt32(0);
                    newConnection.Close();
                    semaphore.Release();
                    return userid;
                    //return userid
                }
                else
                {
                    newConnection.Close();
                    semaphore.Release();
                    return -1;
                    //no user found
                }
            }
        }
        public void BuyCard(string username, string cardid)
        {
            int userid = GetUserid(username);
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();

            using (var OwningCheckCommand = new NpgsqlCommand("SELECT * FROM userstack WHERE userid = @userid AND cardid = @cardid", newConnection))
            {
                OwningCheckCommand.Parameters.AddWithValue("userid", userid);
                OwningCheckCommand.Parameters.AddWithValue("cardid", cardid);

                OwningCheckCommand.Prepare();
                int result = OwningCheckCommand.ExecuteNonQuery();
                if (result == -1)
                {
                    using (var BuyCardCommand = new NpgsqlCommand("INSERT into userstack(userid, cardid, cardamount) VALUES(@userid, @cardid, @cardamount)", newConnection))
                    {
                        BuyCardCommand.Parameters.AddWithValue("userid", userid);
                        BuyCardCommand.Parameters.AddWithValue("cardid", cardid);
                        BuyCardCommand.Parameters.AddWithValue("cardamount", 1);

                        BuyCardCommand.Prepare();
                        BuyCardCommand.ExecuteNonQuery();
                        newConnection.Close();
                        semaphore.Release();
                    }
                }
                else
                {
                    NpgsqlDataReader dr = OwningCheckCommand.ExecuteReader();
                    if (dr.Read())
                    {
                        int CardAmount = dr.GetInt32(3);
                        using (var BuyCardCommand = new NpgsqlCommand("UPDATE userstack SET cardamount = @newcardamount WHERE userid = @userid AND cardid = @cardid", newConnection))
                        {
                            BuyCardCommand.Parameters.AddWithValue("newcardamount", CardAmount + 1);
                            BuyCardCommand.Parameters.AddWithValue("userid", userid);
                            BuyCardCommand.Parameters.AddWithValue("cardid", cardid);

                            BuyCardCommand.Prepare();
                            BuyCardCommand.ExecuteNonQuery();
                        }
                    }
                    newConnection.Close();
                    semaphore.Release();
                }
            }
        }
        public void Pay(int userid, int price)
        {
            int usercoins = GetCoins(userid);
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();


            using (var Command = new NpgsqlCommand("UPDATE usertable SET usercoins = @newcoins WHERE id = @userid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);
                Command.Parameters.AddWithValue("newcoins", usercoins + price);

                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            newConnection.Close();
            semaphore.Release();
        }
        public int GetCoins(int userid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();

            using (var Command = new NpgsqlCommand("SELECT usercoins FROM usertable WHERE id = @userid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);

                Command.Prepare();
                NpgsqlDataReader read = Command.ExecuteReader();
                if (read.Read())
                {
                    int coins = read.GetInt32(0);
                    newConnection.Close();
                    semaphore.Release();
                    return coins;
                }
                newConnection.Close();
                semaphore.Release();
            }
            return -1;
        }
        public List<string> GetOwnedCardsId(int userid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("SELECT cardid FROM userstack WHERE userid = @userid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();

                List<string> list = new List<string>();

                while (dr.Read())
                {
                    list.Add(dr.GetString(0));
                }
                newConnection.Close();
                semaphore.Release();
                return list;
            }
        }
        public List<string> GetCardInfo(string id)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();

            List<string> cardinfo = new List<string>();
                using (var Command = new NpgsqlCommand("SELECT * FROM card WHERE id = @id", newConnection))
                {
                    Command.Parameters.AddWithValue("id", id);

                    Command.Prepare();
                    NpgsqlDataReader dr = Command.ExecuteReader();

                    if (dr.Read())
                    {
                        cardinfo.Add(dr.GetString(1));
                        int carddamage = dr.GetInt32(2);
                        cardinfo.Add(carddamage.ToString());
                        cardinfo.Add(dr.GetString(3));
                        cardinfo.Add(dr.GetString(4));

                        newConnection.Close();
                    semaphore.Release();
                    return cardinfo;
                    }
                    else
                    {
                        newConnection.Close();
                    semaphore.Release();
                    return cardinfo;
                    }
                }
        }
        public List<string> GetCardsFromDeck(int userid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT * FROM deck WHERE userid = @userid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                List<string> list = new List<string>();
                while (dr.Read())
                {
                    list.Add(dr.GetString(2));
                    list.Add(dr.GetString(3));
                    list.Add(dr.GetString(4));
                    list.Add(dr.GetString(5));
                }
                newConnection.Close();
                semaphore.Release();
                return list;

            }
        }
        public int CheckIfCardOwned(int userid, string cardid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT * FROM userstack WHERE userid = @userid AND cardid = @cardid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);
                Command.Parameters.AddWithValue("cardid", cardid);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();

                if (dr.Read())
                {
                    newConnection.Close();
                    semaphore.Release();
                    return 1;
                    //der user besitzt die Karte
                }
                else
                {
                    newConnection.Close();
                    semaphore.Release();
                    return 0;
                    //der user besitzt die Karte nicht
                }
            }
        }
        public void AddCardToDeck(int userid, List<string> cardid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("INSERT into deck(userid, cardid1, cardid2, cardid3, cardid4) VALUES (@userid, @cardid1, @cardid2, @cardid3, @cardid4)", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);
                Command.Parameters.AddWithValue("cardid1", cardid[0]);
                Command.Parameters.AddWithValue("cardid2", cardid[1]);
                Command.Parameters.AddWithValue("cardid3", cardid[2]);
                Command.Parameters.AddWithValue("cardid4", cardid[3]);

                Command.Prepare();
                Command.ExecuteNonQuery();

                newConnection.Close();
                semaphore.Release();
            }
        }
        public int GetCardAmount(int userid, string cardid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();

            using (var Command = new NpgsqlCommand("SELECT cardamount FROM userstack WHERE userid = @userid AND cardid = @cardid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);
                Command.Parameters.AddWithValue("cardid", cardid);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                if (dr.Read())
                {
                    int cardamount = dr.GetInt32(0);
                    newConnection.Close();
                    semaphore.Release();
                    return cardamount;
                }
                else
                {
                    newConnection.Close();
                    semaphore.Release();
                    return 0;
                }

            }
        }
        public void ChangeCardamount(int userid, string cardid, int change)
        {
            int cardamount = GetCardAmount(userid, cardid);
            semaphore.Wait();
            int newcardamount = cardamount + change;
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            if (newcardamount == 0)
            {
                DeleteCardFromStack(userid, cardid);
            }
            

            else if (cardamount >= 1 && newcardamount >= 2)
            {
                using (var Command = new NpgsqlCommand("UPDATE userstack SET cardamount = @newcardamount WHERE userid = @userid AND cardid = @cardid", newConnection))
                {
                    Command.Parameters.AddWithValue("newcardamount", newcardamount);
                    Command.Parameters.AddWithValue("userid", userid);
                    Command.Parameters.AddWithValue("cardid", cardid);

                    Command.Prepare();
                    Command.ExecuteNonQuery();
                    semaphore.Release();
                }
            }
            else if (cardamount == 0 && newcardamount >= 1)
            {
                using (var Command = new NpgsqlCommand("INSERT into userstack(userid, cardid, cardamount) VALUES(@userid, @cardid, @cardamount)", newConnection))
                {
                    Command.Parameters.AddWithValue("userid", userid);
                    Command.Parameters.AddWithValue("cardid", cardid);
                    Command.Parameters.AddWithValue("cardamount", newcardamount);

                    Command.Prepare();
                    Command.ExecuteNonQuery();
                }
            }



            newConnection.Close();
            semaphore.Release();
        }
        public void DeleteCardFromStack(int userid, string cardid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();

            using (var Command = new NpgsqlCommand("DELETE FROM userstack WHERE userid = @userid AND cardid = @cardid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);
                Command.Parameters.AddWithValue("cardid", cardid);

                Command.Prepare();
                Command.ExecuteNonQuery();
            }

            newConnection.Close();
            semaphore.Release();
        }
        public int SetBio(int userid, string name, string bio, string image)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("SELECT * FROM bio WHERE userid = @userid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);
                Command.Prepare();
                int check = Command.ExecuteNonQuery();

                if (check == 1)
                {
                    using(var UpdateCommand = new NpgsqlCommand("UPDATE bio SET name = @name AND bio = @bio AND image = @image WHERE userid = @userid", newConnection))
                    {
                        UpdateCommand.Parameters.AddWithValue("name", name);
                        UpdateCommand.Parameters.AddWithValue("bio", bio);
                        UpdateCommand.Parameters.AddWithValue("image", image);
                        UpdateCommand.Parameters.AddWithValue("userid", userid);

                        UpdateCommand.Prepare();
                        UpdateCommand.ExecuteNonQuery();
                        newConnection.Close();
                        semaphore.Release();
                        return 0;
                        //erfolgreich geupdatet
                    }
                }
                else if(check == -1)
                {
                    using(var CreateCommand = new NpgsqlCommand("INSERT into bio(userid, name, bio, image) VALUES (@userid, @name, @bio, @image)", newConnection))
                    {
                        CreateCommand.Parameters.AddWithValue("userid", userid);
                        CreateCommand.Parameters.AddWithValue("name", name);
                        CreateCommand.Parameters.AddWithValue("bio", bio);
                        CreateCommand.Parameters.AddWithValue("image", image);

                        CreateCommand.Prepare();
                        CreateCommand.ExecuteNonQuery();
                        newConnection.Close();
                        semaphore.Release();
                        return 1;
                        //erfolgreich erstellt
                    }
                }
                newConnection.Close();
                semaphore.Release();
                return -1;
            }
        }
        public List<string> GetBio(int userid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT * FROM bio WHERE userid = @userid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                List<string> bio = new List<string>();

                if (dr.Read())
                {
                    bio.Add(dr.GetString(2));
                    bio.Add(dr.GetString(3));
                    bio.Add(dr.GetString(4));
                }
                newConnection.Close();
                semaphore.Release();
                return bio;
            }
        }
        public List<int> GetStats(int userid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("SELECT * FROM stats WHERE userid = @userid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                List<int> stats = new List<int>();

                if (dr.Read())
                {
                    stats.Add(dr.GetInt32(2));
                    stats.Add(dr.GetInt32(3));
                    stats.Add(dr.GetInt32(4));
                }
                newConnection.Close();
                semaphore.Release();
                return stats;
            }
        }
        public List<int> GetTopUsers()
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT id FROM usertable ORDER BY usereloid DESC", newConnection))
            {
                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();

                List<int> userids = new List<int>();

                while (dr.Read())
                {
                    for(int i = 0; i < 3; i++)
                    {
                        userids.Add(dr.GetInt32(0));
                    }
                }
                newConnection.Close();
                semaphore.Release();
                return userids;
            }
        }
        public List<string> GetUserScoreInfo(int userid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT * FROM usertable WHERE id = @userid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();

                List<string> scoreinfo = new List<string>();

                if (dr.Read())
                {
                    scoreinfo.Add(dr.GetString(1));
                    int elo = dr.GetInt32(4);
                    scoreinfo.Add(elo.ToString());
                }
                newConnection.Close();
                semaphore.Release();
                return scoreinfo;
            }
        }
        public void PostTrade(Trade trade, int userid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("INSERT into trades (tradeid, sellerid, card, type, minimumdamage) VALUES (@id, @sellerid, @card, @type, @damage)", newConnection))
            {
                Command.Parameters.AddWithValue("id", trade.Id);
                Command.Parameters.AddWithValue("sellerid", userid);
                Command.Parameters.AddWithValue("card", trade.CardToTrade);
                Command.Parameters.AddWithValue("type", trade.Type);
                Command.Parameters.AddWithValue("damage", trade.MinimumDamage);

                Command.Prepare();
                Command.ExecuteNonQuery();
                newConnection.Close();
                semaphore.Release();
            }
        }
        public int CheckTradeId(Trade trade)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT tradeid FROM trades WHERE tradeid = @tradeid", newConnection))
            {
                Command.Parameters.AddWithValue("tradeid", trade.Id);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                if (dr.Read())
                {
                    //trade with this id already erxists
                    newConnection.Close();
                    semaphore.Release();
                    return 0;
                }
                else
                {
                    //no trade with this id
                    newConnection.Close();
                    semaphore.Release();
                    return 1;
                }
            }
        }
        public List<string> GetAllTradeIds()
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT tradeid FROM trades", newConnection))
            {

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();

                List<string> tradeIds = new List<string>();
                while (dr.Read())
                {
                    tradeIds.Add(dr.GetString(0));
                }
                newConnection.Close();
                semaphore.Release();
                return tradeIds;
            }
        }
        public string GetCardIdFromTrade(string tradeid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT card FROM trades WHERE tradeid = @tradeid", newConnection))
            {
                Command.Parameters.AddWithValue("tradeid", tradeid);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();

                if (dr.Read())
                {
                    string card = dr.GetString(0);
                    newConnection.Close();
                    semaphore.Release();
                    return card;
                }
                newConnection.Close();
                semaphore.Release();
                return "nix gut";
            }
        }
        public List<string> GetAllTradeWithoutMine(int userid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("SELECT tradeid FROM trades WHERE sellerid != @sellerid", newConnection))
            {
                Command.Parameters.AddWithValue("sellerid", userid);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();

                List<string> tradeIds = new List<string>();
                while (dr.Read())
                {
                    tradeIds.Add(dr.GetString(0));
                }
                newConnection.Close();
                semaphore.Release();
                return tradeIds;
            }
        }
        public int CheckIfTradeIsMine(int userid, string tradeid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT sellerid FROM trades WHERE tradeid = @tradeid", newConnection))
            {
                Command.Parameters.AddWithValue("tradeid", tradeid);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();

                if (dr.Read())
                {
                    if (dr.GetInt32(0) == userid)
                    {
                        newConnection.Close();
                        semaphore.Release();
                        return 1;
                    }
                    else
                    {
                        newConnection.Close();
                        semaphore.Release();
                        return 0;
                    }
                }
                else
                {
                    newConnection.Close();
                    semaphore.Release();
                    return -1;
                }
            }
        }
        public List<string> GetTradeInfos(string tradeid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("SELECT * FROM trades WHERE tradeid = @tradeid", newConnection))
            {
                Command.Parameters.AddWithValue("tradeid", tradeid);

                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();

                List<string> tradeIds = new List<string>();
                while (dr.Read())
                {
                    tradeIds.Add(dr.GetString(0));
                    tradeIds.Add(dr.GetInt32(1).ToString());
                    tradeIds.Add(dr.GetString(2));
                    tradeIds.Add(dr.GetString(3));
                    tradeIds.Add(dr.GetInt32(4).ToString());
                }
                newConnection.Close();
                semaphore.Release();
                return tradeIds;
            }
        }
        public void DeleteTrade(string tradeid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("DELETE FROM trades WHERE tradeid = @tradeid", newConnection))
            {
                Command.Parameters.AddWithValue("tradeid", tradeid);

                Command.Prepare();
                Command.ExecuteNonQuery();
                newConnection.Close();
                semaphore.Release();
            }
        }
        public int GetElo(int userid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();

            using (var Command = new NpgsqlCommand("SELECT usereloid FROM usertable WHERE id = @userid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);
                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                while (dr.Read())
                {
                    int elo = dr.GetInt32(0);
                    newConnection.Close();
                    return elo;
                }
            }
            newConnection.Close();
            semaphore.Release();
            return -1;
        }
        public void UpdateElo(int userid, int change)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();

            int oldelo = GetElo(userid);

            using (var Command = new NpgsqlCommand("UPDATE usertable SET usereloid = @newelo WHERE id = @userid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);
                Command.Parameters.AddWithValue("newelo", oldelo + change);

                Command.Prepare();
                Command.ExecuteNonQuery();
                newConnection.Close();
                semaphore.Release();
            }
            newConnection.Close();
            semaphore.Release();
        }
        public int AddToBattleQueue(int userid, long timestamp)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("SELECT * FROM fightqueue WHERE userid = @userid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);
                Command.Prepare();
                int check = Command.ExecuteNonQuery();
                if(check == -1)
                {
                    using(var AddCommand = new NpgsqlCommand("INSERT into fightqueue (userid, timestamp) VALUES (@userid, @timestamp)", newConnection))
                    {
                        AddCommand.Parameters.AddWithValue("userid", userid);
                        AddCommand.Parameters.AddWithValue("timestamp", timestamp);
                        AddCommand.Prepare();
                        AddCommand.ExecuteNonQuery();
                        newConnection.Close();
                        semaphore.Release();
                        return 1;
                        //user added to queue
                    }
                }
                else
                {
                    newConnection.Close();
                    semaphore.Release();
                    return 0;
                    //already in queue
                }
            }
        }
        public List<int> GetTwoFromQueue()
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("SELECT userid FROM fightqueue ORDER BY timestamp ASC", newConnection))
            {
                Command.Prepare();
                NpgsqlDataReader dr = Command.ExecuteReader();
                List<int> list = new List<int>();
                while (dr.Read())
                {
                    list.Add(dr.GetInt32(0));
                }
                newConnection.Close();
                semaphore.Release();
                return list;

            }
        }
        public void DeleteFromBattleQueue(int userid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("DELETE FROM fightqueue WHERE userid = @userid", newConnection))
            {
                Command.Parameters.AddWithValue("userid", userid);

                Command.Prepare();
                Command.ExecuteNonQuery();

                newConnection.Close();
                semaphore.Release();
            }
        }
        public string GetUsername(int userid)
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("SELECT username FROM usertable WHERE id = @id", newConnection))
            {
                Command.Parameters.AddWithValue("id", userid);
                NpgsqlDataReader dr = Command.ExecuteReader();
                while (dr.Read())
                {
                    string username = dr.GetString(0);
                    newConnection.Close();
                    semaphore.Release();
                    return username;
                }
            }
            newConnection.Close();
            semaphore.Release();
            return "error";
        }
        public void SetStats(int userid, int winnchange, int losechange, int tiechange)
        {
            List<int> stats = new List<int>();
            stats = GetStats(userid);
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            
            if (stats.Count == 0)
            {

                using (var CreateCommand = new NpgsqlCommand("INSERT into stats(userid, wins, losses, ties) VALUES (@userid, @wins, @losses, @ties)", newConnection))
                {
                    int wins = winnchange;
                    int losses = losechange;
                    int ties = tiechange;
                    CreateCommand.Parameters.AddWithValue("userid", userid);
                    CreateCommand.Parameters.AddWithValue("wins", wins);
                    CreateCommand.Parameters.AddWithValue("losses", losses);
                    CreateCommand.Parameters.AddWithValue("ties", tiechange);

                    CreateCommand.Prepare();
                    CreateCommand.ExecuteNonQuery();
                    newConnection.Close();
                    semaphore.Release();

                }
            }
            else
            {

                using (var UpdateCommand = new NpgsqlCommand("UPDATE stats SET wins = @wins, losses = @losses, ties = @ties WHERE userid = @userid", newConnection))
                {
                    int wins = stats[0] + winnchange;
                    int losses = stats[1] + losechange;
                    int ties = stats[2] + tiechange;
                    UpdateCommand.Parameters.AddWithValue("userid", userid);
                    UpdateCommand.Parameters.AddWithValue("wins", wins);
                    UpdateCommand.Parameters.AddWithValue("losses", losses);
                    UpdateCommand.Parameters.AddWithValue("ties", ties);

                    UpdateCommand.Prepare();
                    UpdateCommand.ExecuteNonQuery();
                    newConnection.Close();
                    semaphore.Release();
                }
            }

        }
        public int UniqueFeature(string username, string oldpassword, string newpassword)
        {
            int check = Login(username, oldpassword);
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            
            if(check == 1)
            {
                using(var Command = new NpgsqlCommand("UPDATE usertable SET userpassword = @userpassword WHERE username = @username", newConnection))
                {
                    Command.Parameters.AddWithValue("username", username);
                    Command.Parameters.AddWithValue("userpassword", newpassword);

                    Command.Prepare();
                    Command.ExecuteNonQuery();
                    newConnection.Close();
                    semaphore.Release();
                    return 1;
                }
            }
            else
            {
                newConnection.Close();
                semaphore.Release();
                return 0;
            }
        }
        public void CreateTables()
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using(var Command = new NpgsqlCommand("CREATE TABLE IF NOT EXISTS allpackages(id SERIAL PRIMARY KEY, timestamp BIGINT)", newConnection))
            {
                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            using (var Command = new NpgsqlCommand("CREATE TABLE IF NOT EXISTS bio(id SERIAL PRIMARY KEY, userid INTEGER, name TEXT, bio TEXT, image TEXT)", newConnection))
            {
                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            using(var Command = new NpgsqlCommand("CREATE TABLE IF NOT EXISTS card(id TEXT PRIMARY KEY, cardname TEXT, carddamage INTEGER, cardelementtype TEXT, cardtype TEXT)", newConnection))
            {
                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            using(var Command = new NpgsqlCommand("CREATE TABLE IF NOT EXISTS deck(id SERIAL PRIMARY KEY, userid INTEGER, cardid1 TEXT, cardid2 TEXT, cardid3 TEXT, cardid4 TEXT)", newConnection))
            {
                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            using(var Command = new NpgsqlCommand("CREATE TABLE IF NOT EXISTS fightqueue(userid INTEGER, timestamp BIGINT PRIMARY KEY)", newConnection))
            {
                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            using(var Command = new NpgsqlCommand("CREATE TABLE IF NOT EXISTS packages(id SERIAL PRIMARY KEY, packageid INTEGER, cardid TEXT)", newConnection))
            {
                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            using(var Command = new NpgsqlCommand("CREATE TABLE IF NOT EXISTS stats(id SERIAL PRIMARY KEY, userid INTEGER, wins INTEGER, losses INTEGER, ties INTEGER)", newConnection))
            {
                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            using(var Command = new NpgsqlCommand("CREATE TABLE IF NOT EXISTS tokens(id SERIAL PRIMARY KEY, tokentype TEXT, tokenname TEXT, timestamp BIGINT)", newConnection))
            {
                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            using(var Command = new NpgsqlCommand("CREATE TABLE IF NOT EXISTS trades(tradeid TEXT PRIMARY KEY, sellerid INTEGER, card TEXT, type TEXT, minimumdamage INTEGER)", newConnection))
            {
                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            using(var Command = new NpgsqlCommand("CREATE TABLE IF NOT EXISTS userstack(id SERIAL PRIMARY KEY, userid INTEGER, cardid TEXT, cardamount INTEGER)", newConnection))
            {
                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            using(var Command = new NpgsqlCommand("CREATE TABLE IF NOT EXISTS usertable(id SERIAL PRIMARY KEY, username VARCHAR(50), userpassword VARCHAR(50), usercoins INTEGER, usereloid INTEGER, accounttype VARCHAR(50))", newConnection))
            {
                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            newConnection.Close();
            semaphore.Release();
        }
        public void DropTables()
        {
            semaphore.Wait();
            NpgsqlConnection newConnection = new NpgsqlConnection(connectionString);
            newConnection.Open();
            using (var Command = new NpgsqlCommand("DROP TABLE IF EXISTS allpackages, bio, card, deck, fightqueue, packages, stats, tokens, trades, userstack, usertable", newConnection))
            {
                Command.Prepare();
                Command.ExecuteNonQuery();
            }
            
            newConnection.Close();
            semaphore.Release();
        }

    }
}
