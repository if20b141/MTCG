﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class PrepareFightNight
    {
        public string Fight(string username)
        {
            Response response = new Response();
            FightNight fightNight = new FightNight();
            Timestamp timestamp = new Timestamp();
            PrepareFighter prepareFighter = new PrepareFighter();

            DataHandler.Instance.AddToBattleQueue(DataHandler.Instance.GetUserid(username), timestamp.GetTimestamp());
            List<int> candidates = new List<int>();
            candidates = DataHandler.Instance.GetTwoFromQueue();

            List<string> deckcheck = new List<string>();
            deckcheck = DataHandler.Instance.GetCardsFromDeck(DataHandler.Instance.GetUserid(username));
            if (deckcheck.Count == 0)
            {
                return response.BuildResponse("404 ERROR ", "", "Ihr Deck ist noch leer");
            }
            else
            {
                if (candidates.Count == 1)
                {
                    return response.BuildResponse("201 OK ", "", "Sie sind jetzt in der WarteSchlange");
                }
                else if (candidates.Count > 1)
                {
                    int candidate1 = candidates[0];
                    int candidate2 = candidates[1];
                    candidates.RemoveRange(0, 1);
                    DataHandler.Instance.DeleteFromBattleQueue(candidate1);
                    DataHandler.Instance.DeleteFromBattleQueue(candidate2);
                    FightUser user1 = new FightUser();
                    FightUser user2 = new FightUser();
                    user1 = prepareFighter.PrepareUser(candidate1);
                    user2 = prepareFighter.PrepareUser(candidate2);
                    List<string> result = new List<string>();
                    result = fightNight.Duell(user1, user2);

                    if (result[0] == "1")
                    {
                        Console.WriteLine(user2.Username + " won");
                        string text = result[1] + "\n" + user2.Username + " won the Fight!";
                        return response.BuildResponse("200 OK ", "", text);

                    }
                    else if (result[0] == "2")
                    {
                        Console.WriteLine(user1.Username + " won");
                        string text = result[1] + "\n" + user1.Username + " won the Fight!";
                        return response.BuildResponse("200 OK ", "", text);
                    }
                    else if (result[0] == "3")
                    {
                        Console.WriteLine("tie");
                        string text = result[1] + "\n" + "This epic Fight ended in a Tie!";
                        return response.BuildResponse("200 OK ", "", text);
                    }
                    else
                    {
                        return response.BuildResponse("404 ERROR", "", "ERROR");
                    }


                }
            }
            return response.BuildResponse("404 ERROR", "", "ERROR");
        }
    }
}
