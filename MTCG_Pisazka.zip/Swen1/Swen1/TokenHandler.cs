﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class TokenHandler
    {
        public void CreateToken(string username)
        {
            Timestamp stamp = new Timestamp();

            string token = username + "-mtcgToken";
            int tokencheck = DataHandler.Instance.TokenCheck(token);
            if (tokencheck == 1)
            {
                DataHandler.Instance.SaveToken(token, stamp.GetTimestamp());
                //token existiert noch nicht in db und wird nun abgespeichert
            }
            else if(tokencheck == 0)
            {
                DataHandler.Instance.TokenUpdate(token, stamp.GetTimestamp());
                //token existiert bereits in db und timestamp wird nun geupdatet
            }
        }
        public int TokenCheck(string username)
        {
            Timestamp stamp = new Timestamp();

            string token = username + "-mtcgToken";
            int tokencheck = DataHandler.Instance.TokenCheck(token);
            if(tokencheck == 1)
            {
                return 1;
                //token existiert nicht
            }
            else if(tokencheck == 0)
            {
                DataHandler.Instance.TokenUpdate(token, stamp.GetTimestamp());
                return 0;
                //token existiert und wird geupdatet
            }
            else
            {
                return -1;
                //error
            }
        }

    }
}
