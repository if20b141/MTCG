﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class Threads
    {
        TcpListener server = null;
        CancellationTokenSource tokenSource;

        public Threads(IPAddress adress, int port)
        {
            server = new TcpListener(adress, port);
            tokenSource = new CancellationTokenSource();
        }
        public async Task ThreadGame(TcpClient client, CancellationToken token)
        {
                Menu gamemenu = new Menu();
                GetCommand getCommand = new GetCommand();

                NetworkStream stream = client.GetStream();
                if (client.ReceiveBufferSize > 0)
                {
                    byte[] bytes = new byte[client.ReceiveBufferSize];
                    int bytesRead = await stream.ReadAsync(bytes, 0, bytes.Length, token);
                    string newdata = System.Text.Encoding.ASCII.GetString(bytes);

                    List<string> commands = new List<string>();
                    commands = getCommand.Commands(newdata);

                    //string text = "hallo";


                    string response = "";
                    //"HTTP/1.1 200 OK " + "\n" + "Content-Type: text/plain" +"\n" +"Content-Length: " + text.Length + "\n\n" + text;

                    if (commands.Count == 4)
                    {
                        response = gamemenu.GameMenu(commands[1], commands[2], commands[3], commands[0]);
                    }
                    else if (commands.Count == 3)
                    {
                        response = gamemenu.GameMenu(commands[1], "placeholder", commands[2], commands[0]);
                    }

                    byte[] buffer = System.Text.Encoding.ASCII.GetBytes(response);
                    await stream.WriteAsync(buffer, 0, buffer.Length, token);
                    Console.WriteLine("Sent: {0}", response);
                }
            stream.Dispose();
            client.Close();
        }
        public void Stop()
        {
            tokenSource.Cancel();
        }
        public async Task Threadit()
        {

            server.Start();
            while (!tokenSource.Token.IsCancellationRequested)
            {
                TcpClient client = await server.AcceptTcpClientAsync();
                _ = Task.Run(() => ThreadGame(client, tokenSource.Token), tokenSource.Token);
            }
            server.Stop();

        }
    }
}
