﻿using Newtonsoft.Json.Linq;
using System;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using static System.Net.WebRequestMethods;
using System.Threading;


namespace Swen1
{
    class Program
    {

        static async Task Main()
        {
            //DataHandler.Instance.DropTables();
            //DataHandler.Instance.CreateTables();
            Int32 port = 10001;
            IPAddress localAddr = IPAddress.Parse("127.0.0.1");
            Threads thread = new Threads(localAddr, port);
            thread.Threadit().Wait();
            
        }

    }
}
