﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class PostTrade
    {
        public string PostMyTrade(string username, string body)
        {
            Trade trade = new Trade();
            DeserializeTrade deserializeTrade = new DeserializeTrade();
            Response response = new Response();

            Console.WriteLine("hallo");

            trade = deserializeTrade.dezerialztrade(body);
            int idcheck = DataHandler.Instance.CheckTradeId(trade);
            if (idcheck == 1)
            {
                int check = DataHandler.Instance.CheckIfCardOwned(DataHandler.Instance.GetUserid(username), trade.CardToTrade);
                if (check == 1)
                {
                    DataHandler.Instance.PostTrade(trade, DataHandler.Instance.GetUserid(username));
                    DataHandler.Instance.ChangeCardamount(DataHandler.Instance.GetUserid(username), trade.CardToTrade, -1);
                    return response.BuildResponse("201 OK ", "", "Das Angebot wurde erfolgreich erstellt");
                }
                else if (check == 0)
                {
                    return response.BuildResponse("403 ERROR ", "", "Sie besitzen diese Karte nicht können daher auch nicht mit ihr handeln");
                }
                else
                {
                    return response.BuildResponse("401 ERROR ", "", "ERROR");
                }
            }
            else if(idcheck == 0)
            {
                return response.BuildResponse("409 ERROR ", "", "Es existiert bereits ein Deal mit dieser ID");
            }
            else
            {
                return response.BuildResponse("401 ERROR ", "", "ERROR");
            }

        }
    }
}
