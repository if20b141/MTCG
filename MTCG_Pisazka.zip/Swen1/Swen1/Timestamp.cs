﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class Timestamp
    {
        public long GetTimestamp()
        {
            long time = DateTimeOffset.Now.ToUnixTimeSeconds();
            return time;
        }
    }
}
