﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;

namespace Swen1
{
    public class CheckForTrades
    {
        public string CheckForTradeUrl(string url, string username, string body, string method)
        {
            Response response = new Response();

            List<string> trades = new List<string>();
            trades = DataHandler.Instance.GetAllTradeIds();
            TokenHandler tokenHandler = new TokenHandler();
            int tokencheck = tokenHandler.TokenCheck(username);


            if (trades.Count > 0)
            {

                foreach (string tradeId in trades)
                {
                    if (url == "/tradings/" + tradeId)
                    {
                        int owningcheck = DataHandler.Instance.CheckIfTradeIsMine(DataHandler.Instance.GetUserid(username), tradeId);
                        if (tokencheck == 0)
                        {

                            if (method == "POST" && owningcheck == 0)
                            {
                                List<string> cardinfos = new List<string>();
                                List<string> wantedinfos = new List<string>();
                                DeserializeOffer deserializeOffer = new DeserializeOffer();
                                string offeredcard = deserializeOffer.dezerialzeoffer(body);
                                cardinfos = DataHandler.Instance.GetCardInfo(offeredcard);
                                wantedinfos = DataHandler.Instance.GetTradeInfos(tradeId);
                                int cardowncheck = DataHandler.Instance.CheckIfCardOwned(DataHandler.Instance.GetUserid(username), offeredcard);
                                string tradecard = DataHandler.Instance.GetCardIdFromTrade(tradeId);
                                if (cardowncheck == 1)
                                {
                                    if (wantedinfos[3] == cardinfos[3] && int.Parse(wantedinfos[4]) <= int.Parse(cardinfos[1]))
                                    {
                                        DataHandler.Instance.ChangeCardamount(DataHandler.Instance.GetUserid(username), tradecard, +1);
                                        DataHandler.Instance.ChangeCardamount(DataHandler.Instance.GetUserid(username), offeredcard, -1);
                                        DataHandler.Instance.ChangeCardamount(int.Parse(wantedinfos[1]), offeredcard, +1);
                                        DataHandler.Instance.DeleteTrade(tradeId);

                                        return response.BuildResponse("200 OK ", "", "Der Handel wurde erfolgreich durchgehführt");
                                    }
                                    else
                                    {
                                        return response.BuildResponse("403 ERROR ", "", "Die Karte entspricht nicht den Anfroderungen für den Handel");
                                    }
                                }
                                else if (cardowncheck == 0)
                                {
                                    return response.BuildResponse("403 ERROR ", "", "Der user besitzt die angebotene Karte nicht");
                                }
                            }

                            else if (method == "DELETE" && owningcheck == 1)
                            {
                                Console.WriteLine("passt");
                                string tradecard = DataHandler.Instance.GetCardIdFromTrade(tradeId);
                                DataHandler.Instance.DeleteTrade(tradeId);
                                DataHandler.Instance.ChangeCardamount(DataHandler.Instance.GetUserid(username), tradecard, +1);
                                return response.BuildResponse("200 OK ", "", "Das Handelsangebot wurde erfolgreich zurückgenommen");
                            }
                            else
                            {
                                return response.BuildResponse("404 ERROR ", "", "ERROR");
                            }
                        }
                        else if (tokencheck == 1)
                        {
                            Console.WriteLine("Sie sind nicht angemeldet");
                            return response.BuildResponse("401 ERROR ", "", "Sie sind nicht angemeldet");
                        }


                    }
                }
                return "ok";
            }
            else
            {
                return "ok";
            }
        }
    }
}
