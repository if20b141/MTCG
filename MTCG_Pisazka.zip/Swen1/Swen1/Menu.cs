﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;

namespace Swen1
{
    public class Menu
    {
        public string GameMenu(string url, string token, string body, string method)
        {
            CheckForTrades checkForTrades = new CheckForTrades();
            string response;
            Response response1 = new Response();
            if (url == "/users/" + token)
            {
                TokenHandler tokenHandler = new TokenHandler();
                int tokencheck = tokenHandler.TokenCheck(token);
                if(tokencheck == 0)
                {
                    if (method == "PUT")
                    {
                        SetBio setBio = new SetBio();
                        response = setBio.SetMybio(token, body);
                        return response;
                    }
                    else if(method == "GET")
                    {
                        GetBio getBio = new GetBio();
                        response = getBio.GetMyBio(token);
                        return response;
                    }
                }
                else if (tokencheck == 1)
                {
                    Console.WriteLine("Sie sind nicht angemeldet");
                    return response1.BuildResponse("401 ERROR ", "", "Sie sind nicht angemeldet");
                }
                return response1.BuildResponse("404 ERROR ", "", "ERROR");

            }
            string checkingurltrades = checkForTrades.CheckForTradeUrl(url, token, body, method);
            if(checkingurltrades != "ok"){
                response = checkingurltrades;
                return response;
            }
            switch (url)
            {
                case "/users":
                    {
                        Register register = new Register();
                        response = register.UserRegister(body);
                        return response;
                    }
                case "/sessions":
                    {
                        Login login = new Login();
                        response = login.UserLogin(body);
                        return response;
                    }
                case "/packages":
                    {  
                        TokenHandler tokenHandler = new TokenHandler();
                        int tokencheck = tokenHandler.TokenCheck(token);
                        if (tokencheck == 0)
                        {
                            if (token == "admin")
                            {
                                CreatePackages package = new CreatePackages();
                                package.Create(body);
                                return response1.BuildResponse("201 OK ", "", "Packages wurden erfolgreich erstellt");

                            }
                            else
                            {
                                Console.WriteLine("Sie sind kein Admin und haben hierzu keine Rechte");
                                return response1.BuildResponse("403 ERROR ", "", "Sie sind kein Admin und haben hierzu keine Rechte");
                            }
                        }
                        else if(tokencheck == 1)
                        {
                            Console.WriteLine("Sie sind nicht angemeldet");
                            return response1.BuildResponse("401 ERROR ", "", "Sie sind nicht angemeldet");
                        }
                        return response1.BuildResponse("404 ERROR ", "", "ERROR");
                    }
                case "/transactions/packages":
                    {
                        TokenHandler tokenHandler = new TokenHandler();
                        int tokencheck = tokenHandler.TokenCheck(token);
                        if(tokencheck == 0)
                        {
                            Transactions transactions = new Transactions();
                            return transactions.Packages(token);
                        }
                        else if(tokencheck == 1)
                        {
                            Console.WriteLine("Sie sind nicht angemeldet");
                            return response1.BuildResponse("401 ERROR ", "", "Sie sind nicht angemeldet");
                        }
                        return response1.BuildResponse("404 ERROR ", "", "ERROR");
                    }
                case "/cards":
                    {
                        TokenHandler tokenHandler = new TokenHandler();
                        int tokencheck = tokenHandler.TokenCheck(token);
                        if(tokencheck == 0)
                        {
                            GetCards getCards = new GetCards();
                            return getCards.GetAllOwnedCardsInfo(token);
                        }
                        else if(tokencheck == 1)
                        {
                            Console.WriteLine("Sie sind nicht angemeldet");
                            return response1.BuildResponse("401 ERROR ", "", "Sie sind nicht angemeldet");
                        }
                        return response1.BuildResponse("404 ERROR ", "", "ERROR");
                    }
                case "/deck":
                    {
                        TokenHandler tokenHandler = new TokenHandler();
                        int tokencheck = tokenHandler.TokenCheck(token);
                        if (tokencheck == 0)
                        {
                            if(method == "GET")
                            {
                                GetDeck getDeck = new GetDeck();
                                return getDeck.GetYourDeck(token);
                            }
                            else if(method == "PUT")
                            {
                                SetDeck setDeck = new SetDeck();
                                return setDeck.SetMyDeck(token, body);
                            }
                            
                        }
                        else if (tokencheck == 1)
                        {
                            Console.WriteLine("Sie sind nicht angemeldet");
                            return response1.BuildResponse("401 ERROR ", "", "Sie sind nicht angemeldet");
                        }
                        return response1.BuildResponse("404 ERROR ", "", "ERROR");
                    }
                case "/deck?format=plain":
                    {
                        TokenHandler tokenHandler = new TokenHandler();
                        int tokencheck = tokenHandler.TokenCheck(token);
                        if(tokencheck == 0)
                        {
                            GetDeck getDeck = new GetDeck();
                            return getDeck.GetYourDeck(token);
                        }
                        else if (tokencheck == 1)
                        {
                            Console.WriteLine("Sie sind nicht angemeldet");
                            return response1.BuildResponse("401 ERROR ", "", "Sie sind nicht angemeldet");
                        }
                        return response1.BuildResponse("404 ERROR ", "", "ERROR");
                    }
                case "/stats":
                    {
                        TokenHandler tokenHandler = new TokenHandler();
                        int tokencheck = tokenHandler.TokenCheck(token);
                        if( tokencheck == 0)
                        {
                            GetStats stats = new GetStats();
                            response = stats.GetMyStats(token);
                            return response;
                        }
                        else if (tokencheck == 1)
                        {
                            Console.WriteLine("Sie sind nicht angemeldet");
                            return response1.BuildResponse("401 ERROR ", "", "Sie sind nicht angemeldet");
                        }
                        return response1.BuildResponse("404 ERROR ", "", "ERROR");
                    }
                case "/score":
                    {
                        TokenHandler tokenHandler = new TokenHandler();
                        int tokencheck = tokenHandler.TokenCheck(token);
                        if(tokencheck == 0)
                        {
                            GetScoreBoard getScoreBoard = new GetScoreBoard();
                            response = getScoreBoard.GetScore(token);
                            return response;
                        }
                        else if (tokencheck == 1)
                        {
                            Console.WriteLine("Sie sind nicht angemeldet");
                            return response1.BuildResponse("401 ERROR ", "", "Sie sind nicht angemeldet");
                        }
                        return response1.BuildResponse("404 ERROR ", "", "ERROR");
                    }
                case "/tradings":
                    {
                        TokenHandler tokenHandler = new TokenHandler();
                        int tokencheck = tokenHandler.TokenCheck(token);
                        if(tokencheck == 0)
                        {
                            if(method == "POST")
                            {
                                PostTrade postTrade = new PostTrade();
                                return postTrade.PostMyTrade(token, body);
                            }
                            else if(method == "GET")
                            {
                                GetTrades getTrades = new GetTrades();
                                return getTrades.GetAllTrades(token);
                            }
                        }
                        else if (tokencheck == 1)
                        {
                            Console.WriteLine("Sie sind nicht angemeldet");
                            return response1.BuildResponse("401 ERROR ", "", "Sie sind nicht angemeldet");
                        }
                        return response1.BuildResponse("404 ERROR ", "", "ERROR");
                    }
                case "/battles":
                    {
                        TokenHandler tokenHandler = new TokenHandler();
                        int tokencheck = tokenHandler.TokenCheck(token);
                        if(tokencheck == 0)
                        {
                            PrepareFightNight prepareFightNight = new PrepareFightNight();
                            response = prepareFightNight.Fight(token);
                            return response;
                        }
                        else if (tokencheck == 1)
                        {
                            Console.WriteLine("Sie sind nicht angemeldet");
                            return response1.BuildResponse("401 ERROR ", "", "Sie sind nicht angemeldet");
                        }
                        return response1.BuildResponse("404 ERROR ", "", "ERROR");
                    }
                case "/unique":
                    {
                        TokenHandler tokenHandler = new TokenHandler();
                        DezerializeUnique dezerializeUnique = new DezerializeUnique();
                        List<string> values = new List<string>();
                        values = dezerializeUnique.Deserialize(body);
                        Console.WriteLine(values[0] + " " + values[1] + " " + values[2]);
                        int tokencheck = tokenHandler.TokenCheck(token);
                        if (tokencheck == 0)
                        {

                            int check = DataHandler.Instance.UniqueFeature(values[0], values[1], values[2]);
                            if (check == 1)
                            {
                                return response1.BuildResponse("200 OK ", "", "Sie haben ihr Password erfolgreich geändert!");
                            }
                            else
                            {
                                return response1.BuildResponse("404 ERROR", "", "ERROR");
                            }
                        }
                        else if (tokencheck == 1)
                        {
                            Console.WriteLine("Sie sind nicht angemeldet");
                            return response1.BuildResponse("401 ERROR ", "", "Sie sind nicht angemeldet");
                        }
                        return response1.BuildResponse("404 ERROR ", "", "ERROR");
                    }
                default:
                    return response1.BuildResponse("404 ERROR ", "", "CHAOS");
            }

        }
    }
}
