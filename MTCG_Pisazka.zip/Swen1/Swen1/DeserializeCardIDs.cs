﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class DeserializeCardIDs
    {
        public List<string> Deserialize(string json)
        {
            List<string> cards = new List<string>();
            cards = JsonConvert.DeserializeObject<List<string>>(json);
            return cards;

        }
    }
}
