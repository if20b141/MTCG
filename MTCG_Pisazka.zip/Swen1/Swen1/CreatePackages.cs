﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class CreatePackages
    {
        public void Create(string body)
        {
            List<InputCard> cards = new List<InputCard>();
            DeserializeCard deserializeCard = new DeserializeCard();
            InputCardToCard inputCardToCard = new InputCardToCard();
            cards = deserializeCard.Deserialize(body);
            List<Card> cardsToCreate = new List<Card>();

            foreach(var card in cards)
            {
                cardsToCreate.Add(inputCardToCard.MakeCard(card));
            }
            Timestamp time = new Timestamp();
            int packageid = DataHandler.Instance.CreatePackageId(time.GetTimestamp());
            foreach(var card in cardsToCreate)
            {

                    DataHandler.Instance.CreateCard(card);
                    DataHandler.Instance.CreatePackage(packageid, card.id);
                Console.WriteLine("hallo");
                    //create card and add to pack
            }
            Console.WriteLine("Package wurde erstellt");

            
        }
    }
}
