﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class Deck
    {
        public List<FightCard> CardDeck = new List<FightCard>();

        public int LengthCheck()
        {
            int length = CardDeck.Count;
            return length;
        }

        public void AddCard(FightCard NewCard)
        {
            CardDeck.Add(NewCard);
        }
        public void DeleteCard(FightCard OldCard)
        {
            CardDeck.Remove(OldCard);
        }
    }
}
