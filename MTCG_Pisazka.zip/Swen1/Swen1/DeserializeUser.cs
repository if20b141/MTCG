﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Swen1
{
    public class DeserializeUser
    {
        public User dezerialzeuser(string json)
        {
            User user = new User();
            string[] strings = json.Split("\"");
            int counter = 0;
            foreach (string s in strings)
            {
                if(s == "Username")
                {
                    user.Username = strings[counter + 2];
                }
                else if(s == "Password")
                {
                    user.Password = strings[counter + 2];
                }
                counter++;
            }
            return user;
        }


    }
}
