﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class GetBio
    {
        public string GetMyBio(string username)
        {
            Response response = new Response();
            List<string> bio = new List<string>();
            bio = DataHandler.Instance.GetBio(DataHandler.Instance.GetUserid(username));
            if(bio.Count == 3)
            {
                string responsebody = "{\"Name\": \"" + bio[0] + "\", \"Bio\": \"" + bio[1] + "\",  \"Image\": \"" + bio[2] + "\"}";
                return response.BuildResponse("200 OK ", "Conent-Type: application/json", responsebody);
            }
            else if(bio.Count == 0)
            {
                return response.BuildResponse("403 ERROR ", "", "Ihre Bio ist noch leer");
            }
            else
            {
                return response.BuildResponse("403 ERROR ", "", "Ihre Bio ist noch nicht vollständig");
            }
        }
    }
}
