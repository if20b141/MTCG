﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class InputCardToCard
    {
        public Card MakeCard(InputCard inputcard)
        {
            Card card = new Card();
            card.id = inputcard.Id;
            card.Damage = ((int)inputcard.Damage);
            if(inputcard.Name.Contains("Water") == true)
            {
                card.Element = "Water";
                card.Name = inputcard.Name;
                card.Name = card.Name.Replace("Water", "");
            }
            else if(inputcard.Name.Contains("Fire") == true)
            {
                card.Element = "Fire";
                card.Name = inputcard.Name;
                card.Name = card.Name.Replace("Fire", "");
            }
            else if(inputcard.Name.Contains("Normal") == true)
            {
                card.Name = inputcard.Name;
                card.Name = card.Name.Replace("Normal", "");
            }
            else
            {
                card.Element = "Normal";
                card.Name = inputcard.Name;
            }
            if(inputcard.Name.Contains("Spell") == true)
            {
                card.Type = "Spell";
            }
            else if(inputcard.Name.Contains("Spell") == false)
            {
                card.Type = "Monster";
            }
            return card;
        }
    }
}
