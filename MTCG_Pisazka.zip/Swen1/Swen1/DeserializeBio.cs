﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;


namespace Swen1
{
    public class DeserializeBio
    {
        public TheBio dezerialzebio(string json)
        {
            TheBio bio = new TheBio();
            string[] strings = json.Split("\"");
            int counter = 0;
            foreach (string s in strings)
            {
                if (s == "Name")
                {
                    bio.Name = strings[counter + 2];
                }
                else if (s == "Bio")
                {
                    bio.Bio = strings[counter + 2];
                }
                else if(s == "Image")
                {
                    bio.Image = strings[counter + 2];
                }
                counter++;
            }
            return bio;
        }
    }
}
