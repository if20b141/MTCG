﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class GetStats
    {
        public string GetMyStats(string username)
        {
            Response response = new Response();

            List<int> stats = new List<int>();
            stats = DataHandler.Instance.GetStats(DataHandler.Instance.GetUserid(username));
            if (stats.Count == 3)
            {
                string responsebody = "{\"WINS\": \"" + stats[0].ToString() + "\", \"LOSSES\": \"" + stats[1].ToString() + "\",  \"TIES\": \"" + stats[2].ToString() + "\"}";
                return response.BuildResponse("200 OK ", "--header Conent-Type: application/json", responsebody);
            }
            else if (stats.Count == 0)
            {
                return response.BuildResponse("403 ERROR ", "", "Ihre Stats sind noch leer. Sie haben anscheinend noch nicht gekämpft");
            }
            else
            {
                return response.BuildResponse("404 ERROR ", "", "ERROR");
            }
        }
    }
}
