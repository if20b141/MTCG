﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class Response
    {
        public string BuildResponse(string StatusCode, string Headers, string Body)
        {
            string response = "HTTP/1.1 " + StatusCode + "\n" + Headers + "\n" + "Conten-Length: " + Body.Length + "\n" + "\n" + Body;
            return response;    
        }
    }
}
