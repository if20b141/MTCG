﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Swen1
{
    public class DeserializeTrade
    {
        public Trade dezerialztrade(string json)
        {
            Trade trade = new Trade();
            string[] strings = json.Split("\"");
            int counter = 0;
            foreach (string s in strings)
            {
                if (s == "Id")
                {
                    trade.Id = strings[counter + 2];
                }
                else if (s == "CardToTrade")
                {
                    trade.CardToTrade = strings[counter + 2];
                }
                else if (s == "Type")
                {
                    trade.Type = strings[counter + 2];
                }
                else if(s == "MinimumDamage")
                {
                    string cut = strings[counter +1].Trim();
                    cut = cut.Replace(":", "");
                    cut = cut.Replace("}", "");
                    int damage = Int32.Parse(cut);
                    trade.MinimumDamage = damage;
                    
                }
                counter++;
            }
            return trade;
        }
    }
}
