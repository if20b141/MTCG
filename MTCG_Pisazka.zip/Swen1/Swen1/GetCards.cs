﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class GetCards
    {
        public string GetAllOwnedCardsInfo(string username)
        {
            Response response = new Response();

            List <string> cardids = new List<string>();
            cardids = DataHandler.Instance.GetOwnedCardsId(DataHandler.Instance.GetUserid(username));
            if (cardids.Count > 0)
            {

                List<string> cardinfo = new List<string>();
                string toreturn = "";

                foreach (string cardid in cardids)
                {
                    cardinfo = DataHandler.Instance.GetCardInfo(cardid);
                    if (cardinfo.Count == 4)
                    {
                        Console.WriteLine(cardinfo[0] + " " + cardinfo[1] + " " + cardinfo[2] + " " + cardinfo[3]);
                        toreturn += "{\"Name\": \"" + cardinfo[0] + "\", \"Damage\": \"" + cardinfo[1] + "\", \"Element\": \"" + cardinfo[2] + "\", \"Type\": \"" + cardinfo[3] + "\"}, ";
                    }
                }
                return response.BuildResponse("200 OK ", "--header Content-Type: application/json","[" + toreturn + "]" + "\n");
            }
            else
            {
                return response.BuildResponse("203 OK ", "", "Der User besitzt keine Karten");
            }
            
        }
    }
}
