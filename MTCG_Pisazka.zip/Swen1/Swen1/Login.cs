﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class Login
    {
        public string UserLogin(string body)
        {
            Response response = new Response();
            User user = new User();
            DeserializeUser deserialize = new DeserializeUser();
            user = deserialize.dezerialzeuser(body);
            TokenHandler tokenHandler = new TokenHandler();
            int check = DataHandler.Instance.UserNameCheck(user.Username);
            if (check == 0)
            {
                int logincheck = DataHandler.Instance.Login(user.Username, user.Password);
                if (logincheck == 1)
                {
                    tokenHandler.CreateToken(user.Username);
                    Console.WriteLine("Sie haben sich erfolgreich angemeldet");
                    return response.BuildResponse("200 OK ", "", "Sie haben sich erolgreich angemeldet");
                    
                }
                else if (logincheck == -1)
                {
                    Console.WriteLine("Falsches Password");
                    return response.BuildResponse("401 ERORR", "", "Falsches Passwort");
                    
                }
            }
            else if (check == 1)
            {
                Console.WriteLine("Der User existiert nicht");
                return response.BuildResponse("401 ERROR", "", "Der User existiert nicht in der Datenbank");
                
            }
            return response.BuildResponse("404 ERROR", "", "ERROR");
        }
    }
}
