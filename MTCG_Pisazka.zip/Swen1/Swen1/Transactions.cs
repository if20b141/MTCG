﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class Transactions
    {
        public string Packages(string username)
        {
            Response response = new Response();
            
            int packageid = DataHandler.Instance.GetPackages();
            if (packageid != -1)
            {

                List<string> list = new List<string>();
                list = DataHandler.Instance.GetCardsFromPack(packageid);
                if (DataHandler.Instance.GetCoins(DataHandler.Instance.GetUserid(username)) >= 5)
                {
                    foreach (string card in list)
                    {
                        DataHandler.Instance.BuyCard(username, card);
                    }
                    DataHandler.Instance.Pay(DataHandler.Instance.GetUserid(username), -5);
                    DataHandler.Instance.DeletePackage(packageid);
                    return response.BuildResponse("200 OK ", "", "Sie haben sich erfolgreich ein Pack gekauft");
                }
                else
                {
                    return response.BuildResponse("403 ERROR ", "", "Sie besitzen nicht genug Coins um sich ein Pack zu kaufen");
                }
            }
            else
            {
                return response.BuildResponse("404 ERROR ", "", "ERROR");
            }

        }
    }
}
