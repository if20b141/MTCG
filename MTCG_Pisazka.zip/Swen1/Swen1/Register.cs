﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class Register
    {
        public string UserRegister(string body)
        {
            Response response = new Response();
            User user = new User();
            DeserializeUser deserialize = new DeserializeUser();
            user = deserialize.dezerialzeuser(body);
            int check = DataHandler.Instance.UserNameCheck(user.Username);
            if (check == 0)
            {
                Console.WriteLine("User existiert bereits!");
                return response.BuildResponse("409 ERROR ", "", "User existiert bereits");
            }
            else if (check == 1)
            {
                DataHandler.Instance.RegisterUser(user.Username, user.Password);
                Console.WriteLine("User wurde erfolgreich angelegt!");
                return response.BuildResponse("200 OK ", "", "User wurde erfolgreich angelegt");

            }
            return response.BuildResponse("404 ERROR ", "", "ERROR");

        }
    }
}
