﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swen1
{
    public class FightNight
    {
        public List<string> Attack(FightCard Card1, FightCard Card2)
        {
            List<string> toreturn = new List<string>();
            List<string> Card1InstaKill = new List<string>();
            List<string> Card2InstaKill = new List<string>();
            Card1InstaKill = Card1.Specialities(Card2);
            Card2InstaKill = Card2.Specialities(Card1);
            int Card1Effectivness = Card1.Effectiveness(Card2);
            int Card2Effectvness = Card2.Effectiveness(Card1);
            int EffectivenessCheck = Card1.EffectivenessCheck(Card2);

            Console.WriteLine("PlayerA: " + Card1.ElementType + Card1.Name + "(" + Card1.Damage.ToString() + " Damage) vs PlayerB: " + Card2.ElementType + Card2.Name + "(" + Card2.Damage.ToString() + " Damage) => ");
            string text = "PlayerA: " + Card1.ElementType + Card1.Name + "(" + Card1.Damage.ToString() + " Damage) vs PlayerB: " + Card2.ElementType + Card2.Name + "(" + Card2.Damage.ToString() + " Damage) => ";
            if (Card1InstaKill[0] == "1")
            {
                toreturn.Add("0");
                text += Card1InstaKill[1];
                toreturn.Add(text);
                return toreturn;
                // card2 auto wins
            }
            else if (Card2InstaKill[0] == "1")
            {
                toreturn.Add("1");
                text += Card2InstaKill[1];
                toreturn.Add(text);
                return toreturn;
                //card1 auto wins
            }
            else
            {
                string result;
                if (EffectivenessCheck == 0||(Card1Effectivness == 0 && Card2Effectvness == 0))
                {
                    //fight without effectiveness
                    if (Card1.Damage > Card2.Damage)
                    {

                        Console.WriteLine(Card1.Name + " defeats " + Card2.Name);
                        result = Card1.Name + " defeats " + Card2.Name;
                        toreturn.Add("1");
                        toreturn.Add(text);
                        toreturn.Add(result);
                        return toreturn;
                        // card1 wins
                    }
                    else if (Card1.Damage < Card2.Damage)
                    {
                        Console.WriteLine(Card2.Name + " defeats " + Card1.Name);
                        result = Card2.Name + " defeats " + Card1.Name;
                        toreturn.Add("0");
                        toreturn.Add(text);
                        toreturn.Add(result);
                        return toreturn;
                        //card 2 wins
                    }
                    else if (Card1.Damage == Card2.Damage)
                    {
                        Console.WriteLine("DRAW!");
                        result = "DRAW";
                        toreturn.Add("2");
                        toreturn.Add(text);
                        toreturn.Add(result);
                        return toreturn;
                        //draw
                    }
                    else
                    {
                        toreturn.Add("-1");
                        toreturn.Add("ERROR");
                        return toreturn;
                    }
                }
                else if (Card1Effectivness == 1)
                {
                    int TempDamage1 = Card1.Damage * 2;
                    int TempDamage2 = Card2.Damage / 2;
                    Console.WriteLine(Card1.Damage.ToString() + " VS " + Card2.Damage.ToString() + " -> " + TempDamage1.ToString() + " VS " + TempDamage2.ToString() + " =>");
                    text += Card1.Damage.ToString() + " VS " + Card2.Damage.ToString() + " -> " + TempDamage1.ToString() + " VS " + TempDamage2.ToString() + " =>";

                    if (TempDamage1 > TempDamage2)
                    {
                        Console.WriteLine(Card1.ElementType + Card1.Name + " wins!");
                        result = Card1.ElementType + Card1.Name + " wins!";

                        toreturn.Add("1");
                        toreturn.Add(text);
                        toreturn.Add(result);
                        return toreturn;
                        //card1 wins
                    }
                    else if (TempDamage1 < TempDamage2)
                    {
                        Console.WriteLine(Card2.ElementType + Card2.Name + " wins!");
                        result = Card2.ElementType + Card2.Name + " wins!";

                        toreturn.Add("0");
                        toreturn.Add(text);
                        toreturn.Add(result);
                        return toreturn;
                        //card2 wins
                    }
                    else if (TempDamage1 == TempDamage2)
                    {
                        Console.WriteLine("DRAW!");
                        result = "DRAW";
                        toreturn.Add("2");
                        toreturn.Add(text);
                        toreturn.Add(result);
                        return toreturn;
                        //draw
                    }
                    else
                    {
                        toreturn.Add("-1");
                        toreturn.Add("ERROR");
                        return toreturn;
                    }
                    //card1 deals double damage and card 2 takes double damage
                }
                else if (Card2Effectvness == 1)
                {
                    int TempDamage1 = Card1.Damage / 2;
                    int TempDamage2 = Card2.Damage * 2;
                    Console.WriteLine(Card1.Damage.ToString() + " VS " + Card2.Damage.ToString() + " -> " + TempDamage1.ToString() + " VS " + TempDamage2.ToString() + " =>");

                    if (TempDamage1 > TempDamage2)
                    {
                        Console.WriteLine(Card1.ElementType + Card1.Name + " wins!");
                        result = Card1.ElementType + Card1.Name + " wins!";

                        toreturn.Add("1");
                        toreturn.Add(text);
                        toreturn.Add(result);
                        return toreturn;
                        //card1 wins
                    }
                    else if (TempDamage1 < TempDamage2)
                    {
                        Console.WriteLine(Card2.ElementType + Card2.Name + " wins!");
                        result = Card2.ElementType + Card2.Name + " wins!";

                        toreturn.Add("0");
                        toreturn.Add(text);
                        toreturn.Add(result);
                        return toreturn;
                        //card2 wins
                    }
                    else if (TempDamage1 == TempDamage2)
                    {
                        Console.WriteLine("DRAW!");
                        result = "DRAW";
                        toreturn.Add("2");
                        toreturn.Add(text);
                        toreturn.Add(result);
                        return toreturn;
                        //draw
                    }
                    else
                    {
                        toreturn.Add("-1");
                        toreturn.Add("ERROR");
                        return toreturn;
                    }

                }
                else
                {
                    toreturn.Add("-1");
                    toreturn.Add("ERROR");
                    return toreturn;
                }


            }
          
        }
        public List<string> Fight(Deck Deck1, Deck Deck2)
        {
            int Counter = 0;
            int Deck1Length = Deck1.LengthCheck();
            int Deck2Length = Deck2.LengthCheck();
            string result = "";
            while ((Deck1Length > 0 && Deck2Length > 0) && Counter <= 100)
            {
                Console.WriteLine("fight");
                Random rnd = new Random();
                Deck1Length = Deck1.LengthCheck();
                Deck2Length = Deck2.LengthCheck();
                int RandomCard1;
                int RandomCard2;
                if (Deck1Length > 1)
                {

                    RandomCard1 = rnd.Next(0, Deck1Length);
                }
                else
                {
                    RandomCard1 = 0;
                }
                Console.WriteLine(RandomCard1 + " " + Deck1Length);
                if (Deck2Length > 1)
                {
                    RandomCard2 = rnd.Next(0, Deck2Length);
                }
                else
                {
                    RandomCard2 = 0;
                }
                Console.WriteLine(RandomCard2 + " " + Deck2Length);
                List<string> roundresult = new List<string>();
                roundresult = Attack(Deck1.CardDeck[RandomCard1], Deck2.CardDeck[RandomCard2]);
                if (roundresult[0] == "1")
                {
                    Deck1.AddCard(Deck1.CardDeck[RandomCard2]);
                    Deck2.DeleteCard(Deck2.CardDeck[RandomCard2]);
                }
                else if (roundresult[0] == "0")
                {
                    Deck2.AddCard(Deck1.CardDeck[RandomCard1]);
                    Deck1.DeleteCard(Deck1.CardDeck[RandomCard1]);
                }
                else
                {
                    // draw
                }
                result += roundresult[1];
                result += roundresult[2];
                result += "\n";
                Deck1Length = Deck1.LengthCheck();
                Deck2Length = Deck2.LengthCheck();
            }
            List<string> toreturn = new List<string>();
            if (Deck1.LengthCheck() == 0)
            {
                toreturn.Add("0");
                toreturn.Add(result);
                return toreturn;
                //user2 wins fight
            }
            else if (Deck2.LengthCheck() == 0)
            {
                toreturn.Add("1");
                toreturn.Add(result);
                return toreturn;
                //user1 wins fight
            }
            else
            {
                toreturn.Add("2");
                toreturn.Add(result);
                return toreturn;
                // over 100 rounds
            }
        }
        public List<string> Duell(FightUser Fighter1, FightUser Fighter2)
        {
            List<string> toreturn = new List<string>();
            List<string> winner = new List<string>();
            winner = Fight(Fighter1.UserDeck, Fighter2.UserDeck);

            if (winner[0] == "0")
            {
                DataHandler.Instance.UpdateElo(DataHandler.Instance.GetUserid(Fighter2.Username), 3);
                DataHandler.Instance.UpdateElo(DataHandler.Instance.GetUserid(Fighter1.Username), -5);
                DataHandler.Instance.SetStats(DataHandler.Instance.GetUserid(Fighter1.Username), 0, 1, 0);
                DataHandler.Instance.SetStats(DataHandler.Instance.GetUserid(Fighter2.Username), 1, 0, 0);
                toreturn.Add("1");
                toreturn.Add(winner[1]);
                return toreturn;
            }
            else if (winner[0] == "1")
            {
                DataHandler.Instance.UpdateElo(DataHandler.Instance.GetUserid(Fighter1.Username), 3);
                DataHandler.Instance.UpdateElo(DataHandler.Instance.GetUserid(Fighter2.Username), -5);
                DataHandler.Instance.SetStats(DataHandler.Instance.GetUserid(Fighter1.Username), 1, 0, 0);
                DataHandler.Instance.SetStats(DataHandler.Instance.GetUserid(Fighter2.Username), 0, 1, 0);
                toreturn.Add("2");
                toreturn.Add(winner[1]);
                return toreturn;
            }
            else if (winner[0] == "2")
            {
                DataHandler.Instance.SetStats(DataHandler.Instance.GetUserid(Fighter1.Username), 0, 0, 1);
                DataHandler.Instance.SetStats(DataHandler.Instance.GetUserid(Fighter2.Username), 0, 0, 1);
                toreturn.Add("3");
                toreturn.Add(winner[1]);
                return toreturn;
                // no winner
            }
            else
            {
                toreturn.Add("-1");
                toreturn.Add("ERROR");
                return toreturn;
            }
            //attack for whole deck of the user
        }
    }
}
